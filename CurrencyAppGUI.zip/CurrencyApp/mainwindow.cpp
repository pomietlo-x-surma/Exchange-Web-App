#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "registerdialog.h"
#include "logindialog.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}



void MainWindow::on_registerbutton_clicked()
{
    RegisterDialog registerDialog(this); // Tworzenie instancji okna dialogowego
    registerDialog.exec(); // Wyświetlenie okna dialogowego
}


void MainWindow::on_loginButton_clicked()
{
    LoginDialog loginDialog(this);
    loginDialog.exec();
}

